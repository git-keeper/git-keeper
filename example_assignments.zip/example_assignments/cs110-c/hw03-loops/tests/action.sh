python3 action.py $1
