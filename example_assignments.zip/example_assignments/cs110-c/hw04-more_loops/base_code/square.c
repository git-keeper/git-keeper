/*

Write a program which prints out a "square" of asterisks (*'s) with a size
specified by the user. If the size specified by the user is n, then there must
be n rows of n asterisks each. Here is an example run:

Enter the size of the square: 5
*****
*****
*****
*****
*****

 */

