/*

Write a program which prints out an empty diamond of asterisks (*'s) with a
size specified by the user. On each line there must not be any spaces between
the last asterisk and the newline.

The size specifies the number of rows from the first row to the widest row.

Example output:

Enter the size of the diamond: 4
   *
  * *
 *   *
*     *
 *   *
  * *
   *

*/

