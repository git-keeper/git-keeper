# Write a program that asks the user to enter a positive integer and then
# prints out the 3n + 1 sequence starting with that integer until the sequence
# reaches 1. Print each number of the sequence on its own line.
#
# For example, if the user enters the number 13, your program should print this:
# 13
# 40
# 20
# 10
# 5
# 16
# 8
# 4
# 2
# 1

