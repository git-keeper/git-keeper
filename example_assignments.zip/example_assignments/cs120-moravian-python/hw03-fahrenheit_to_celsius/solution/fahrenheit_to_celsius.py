f_temp = eval(input("Enter a temperature in F: "))

c_temp = (f_temp - 32) * 5/9

print("That temperature is", c_temp, "degrees celsius.")
