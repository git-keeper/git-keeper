# Loop through the lines of measles.txt and print out each country in the file
# on its own line. Each country must be printed exactly once. Print the
# countries in the same order that they appear in the file, and make sure any
# spaces after the country name are stripped off.
#
# The first few lines should look like this:
# Afghanistan
# Albania
# Algeria
# Andorra
# ...
