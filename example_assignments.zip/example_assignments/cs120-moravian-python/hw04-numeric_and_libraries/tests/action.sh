#!/bin/bash

bash test_twenty_dollar_bills.sh $1

echo ""

bash test_weeks_and_days.sh $1

exit 0
