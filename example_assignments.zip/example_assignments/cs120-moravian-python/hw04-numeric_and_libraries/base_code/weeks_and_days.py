# Write your program to calculate the number of weeks and days here.
