# Write your program to calculate the number of twenty dollar bills needed here
