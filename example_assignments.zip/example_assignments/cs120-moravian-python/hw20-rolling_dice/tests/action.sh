echo "Your submission has been received. There are no automated tests for this assignment."

exit 0

