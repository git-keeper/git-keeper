echo "Your submission has been received. I will grade this assignment manually."
exit 0
