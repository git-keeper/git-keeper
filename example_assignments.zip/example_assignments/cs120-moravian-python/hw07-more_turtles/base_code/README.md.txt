# More Turtles!

Write a program to draw something using the turtle library. Use 2 or more
turtles, each a different color. Use at least 2 loops in your program. Be as
creative as you want! Write your program in the included more_turtles.py.

Note that since this is such an open-ended assignment, the grader will not
automatically check your work. I will grade this assignment manually, but you
will still turn it in by pushing to the grader.
