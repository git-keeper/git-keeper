# Loop over a range to print out the numbers 13 through 45, each on its own
# line.

for x in range(13, 46):
    print(x)
