# Use range with a step to print out the squares of all the even numbers from 2
# to 18, each on its own line.

for x in range(2, 19, 2):
    print(x * x)
