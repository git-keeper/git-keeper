# Loop over a range to print out the numbers 0 through 50, each on its own
# line.
