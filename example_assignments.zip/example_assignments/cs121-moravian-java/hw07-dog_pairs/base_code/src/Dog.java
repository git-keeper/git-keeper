/**
 * This is a simple Dog class which simply stors a name and provides
 * a method getName() to retrieve the name.
 */
public class Dog {
    private String name;

    public Dog(String dogName) {
        name = dogName;
    }

    public String getName() {
        return name;
    }
}
