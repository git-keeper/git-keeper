/**
 * This class provides a static method which prints out all possible pairs of Dog
 * names from an array of Dog references. No Dog should be paired with itself
 * and each Dog should be paired with each other Dog only once.
 */
public class DogPairPrinter {
    public static void printDogPairs(Dog[] dogs) {
        // implement this method
    }
}
