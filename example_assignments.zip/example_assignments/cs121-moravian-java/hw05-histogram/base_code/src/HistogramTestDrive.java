public class HistogramTestDrive {
    public static void main(String[] args) {
	// Write code to try out your Histogram class here

    }
}
