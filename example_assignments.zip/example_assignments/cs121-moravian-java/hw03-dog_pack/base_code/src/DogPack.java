public class DogPack {
    private Dog[] dogs;

    public DogPack(String[] dogNames) {
        // Complete this constructor.

        // Initialize the dogs array to be a new array that is the same
        // length as dogNames.

        // Use a loop to initialize each Dog reference in the dogs array
        // to refer to a new Dog. Each Dog in dogs should have the corresponding
        // name in the parallel dogNames array.

    }

    public void makeRuckus() {
        // Complete this function.

        // Use a loop to make each dog talk.

    }
}
