public class DogPackTestDrive {
    public static void main(String[] args) {
        String[] dogNames = {"Linda", "Steve", "Clarence"};
        DogPack pack = new DogPack(dogNames);
        pack.makeRuckus();
    }
}
