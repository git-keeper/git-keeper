public class AssignmentGrade {
    private String name;
    private double grade;

    public AssignmentGrade(String assgnName, double assgnGrade) {
        name = assgnName;
        grade = assgnGrade;
    }

    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }
}
